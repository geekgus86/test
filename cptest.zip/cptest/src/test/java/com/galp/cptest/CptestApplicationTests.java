package com.galp.cptest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CptestApplicationTests {

	@Test
	void contextLoads() {
	}

}
