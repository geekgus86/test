package com.galp.cptest.model;

import java.util.Hashtable;

public class cp_area {
	int zip_code;
	String locality;
	String federalEnt;
	Hashtable<String,String> settlements = new Hashtable<String,String>();
	String municipality;
	
	
	public int getZip_code() {
		return zip_code;
	}
	public void setZip_code(int zip_code) {
		this.zip_code = zip_code;
	}
	public String getLocality() {
		return locality;
	}
	public void setLocality(String locality) {
		this.locality = locality;
	}
	public String getFederalEnt() {
		return federalEnt;
	}
	public void setFederalEnt(String federalEnt) {
		this.federalEnt = federalEnt;
	}
	public Hashtable<String, String> getSettlements() {
		return settlements;
	}
	public void setSettlements(Hashtable<String, String> settlements) {
		this.settlements = settlements;
	}
	public String getMunicipality() {
		return municipality;
	}
	public void setMunicipality(String municipality) {
		this.municipality = municipality;
	}
	
	
}
