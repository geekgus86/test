package com.galp.cptest.controller;

import java.util.Hashtable;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.galp.cptest.entity.cps;
import com.galp.cptest.model.cp_area;
import com.galp.cptest.repository.cpRepository;

@RestController
@CrossOrigin
public class cpController {
	
	@Autowired
    private cpRepository cpR;
	
	@RequestMapping(path = "{cp}", method = RequestMethod.GET)
    public ResponseEntity<cp_area> getReport(@PathVariable("cp") String cp) {

		List<cps> findByCp = cpR.findByDCodigo(cp);
		
		cp_area cpFormat = new cp_area();
		Hashtable<String,String> pass = new Hashtable<String,String>();
		
		if(findByCp.size()>0) {
			for(int i = 0; i < findByCp.size(); i++){
			
				cpFormat.setZip_code(Integer.valueOf(findByCp.get(i).getD_codigo()));
				cpFormat.setLocality(findByCp.get(i).getD_ciudad());
				cpFormat.setFederalEnt(findByCp.get(i).getD_estado());
				pass.put("name", findByCp.get(i).getD_asenta());
				pass.put("zone_type", findByCp.get(i).getD_zona());
				pass.put("settlement_type", findByCp.get(i).getD_tipo_asenta());
				cpFormat.setSettlements(pass);
				cpFormat.setMunicipality(findByCp.get(i).getD_mnpio());
			
		}
		
			return new ResponseEntity<cp_area>(cpFormat, HttpStatus.OK);
		}else {
			return new ResponseEntity("{}",HttpStatus.NOT_FOUND);
		}
		
	}
    
    @RequestMapping(path = "/", method = RequestMethod.GET)
    public ResponseEntity getRoot() {
    	return new ResponseEntity(HttpStatus.NOT_FOUND);
    }
	


}
