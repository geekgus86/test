package com.galp.cptest.entity;


import javax.persistence.*;

@Entity
@Table(name = "cps", schema = "dbo")
public class cps {

    private static final long serialVersionUID = 1L;

    @Id
    @Column
    private String d_codigo;
    @Column
    private String d_asenta;
    @Column
    private String d_tipo_asenta;
    @Column
    private String d_mnpio;
    @Column
    private String d_estado;
    @Column
    private String d_ciudad;
    @Column
    private String d_zona;
    
    public cps(String d_codigo, String d_asenta, String d_tipo_asenta, String d_mnpio, String d_estado,String d_ciudad, String d_zona) {
    	this.d_codigo = d_codigo;
    	this.d_asenta = d_asenta;
    	this.d_tipo_asenta = d_tipo_asenta;
    	this.d_mnpio = d_mnpio;
    	this.d_estado = d_estado;
    	this.d_ciudad = d_ciudad;
    	this.d_zona = d_zona;
    }
    
    public cps() {
    	
    }
    
	public String getD_codigo() {
		return d_codigo;
	}
	public void setD_codigo(String d_codigo) {
		this.d_codigo = d_codigo;
	}
	public String getD_asenta() {
		return d_asenta;
	}
	public void setD_asenta(String d_asenta) {
		this.d_asenta = d_asenta;
	}
	public String getD_tipo_asenta() {
		return d_tipo_asenta;
	}
	public void setD_tipo_asenta(String d_tipo_asenta) {
		this.d_tipo_asenta = d_tipo_asenta;
	}
	public String getD_mnpio() {
		return d_mnpio;
	}
	public void setD_mnpio(String d_mnpio) {
		this.d_mnpio = d_mnpio;
	}
	public String getD_estado() {
		return d_estado;
	}
	public void setD_estado(String d_estado) {
		this.d_estado = d_estado;
	}
	public String getD_ciudad() {
		return d_ciudad;
	}
	public void setD_ciudad(String d_ciudad) {
		this.d_ciudad = d_ciudad;
	}
	public String getD_zona() {
		return d_zona;
	}
	public void setD_zona(String d_zona) {
		this.d_zona = d_zona;
	}

    

}
